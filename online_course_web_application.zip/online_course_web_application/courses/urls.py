from django.contrib import admin
from django.urls import path,include
from courses.views import home,couponcode,MyCoursesList,coursePage,SignupView,LoginView,signout,checkout,verifypayment
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('',home, name = 'home'),
    path('mycourse',MyCoursesList.as_view(), name = 'mycourse'),
    path('signup',SignupView.as_view(), name = 'signup'),
    path('logout',signout, name = 'logout'),
    path('login',LoginView.as_view(),name = 'login'),
    path('course/<str:slug>', coursePage, name = 'coursespage'),
    path('check-out/<str:slug>', checkout, name = 'checkout'),
    path('verify_payment',verifypayment , name = 'verifypayment'),
    path('couponcode',couponcode, name = 'couponcode')

]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

urlpatterns +=static(settings.STATIC_URL, document_root=settings.STATIC_ROOT) 