from django.db import models
from courses.models import Course

class Coupon(models.Model):
    couponCode = models.CharField(max_length= 50 , null = False)
    discount = models.IntegerField(null = False , default = 0)
    startdate = models.DateTimeField()
    enddate = models.DateTimeField()

    def __str__(self):
        return self.couponCode