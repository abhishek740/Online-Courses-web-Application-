from courses.models.courses import Course , Prerequisite, Tag , Learning
from courses.models.video import Video
from courses.models.user_course import UserCourse
from courses.models.payment import Payment
from courses.models.contact import Message
from courses.models.coupon import Coupon