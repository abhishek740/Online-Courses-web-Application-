from django.db import models
from courses.models import Course
from django.contrib.auth.models import User 

class Message(models.Model):
    email  = models.EmailField(max_length = 30)
    name = models.CharField(max_length = 20)
    message = models.CharField(max_length = 500)
    
    def __str__(self):
        return self.name
