from django.shortcuts import render
from django.http import HttpResponse
from courses.models.coupon import Coupon

from django.views.generic import ListView

# functions 
def couponcode(request):
    if request.method == 'GET':
        code = Coupon.objects.all()
        data = {
            "code":code
        }
        return render(request,'courses\couponcode.html',data)
    else:
        code = Coupon.objects.get(pk=3)   
        discount = code.discount
        
        postdata = request.POST
        coupon = postdata.get('coupon')
        price = postdata.get('price')
        error = None
        print(price)
        print(coupon)
        print(code)
        print(discount)
        if not (str(code) == str(coupon)):
            code = Coupon.objects.all()
            error = "Coupon code is not valid"
            data = {
                "code":code,
                "error":error
            }
            
            return render(request,'courses\couponcode.html',data)

        else:
            price = int(price) - int(discount)
            print(price)
            price = int(price)
            return render(request,'courses\couponcode.html',{"price":price})
        