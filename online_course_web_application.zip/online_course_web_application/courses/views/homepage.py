from django.shortcuts import render
from django.http import HttpResponse
from courses.models.courses import Course
from courses.models.contact import Message
from django.views.generic import ListView
# list view class 
from django.views.generic import ListView

# class HomePageView(ListView):
#     template_name = "courses\home.html"
#     queryset = Course.objects.filter(active=True)
#     context_object_name = 'courses'

def home(request):
    courses = Course.objects.all()  
    if request.method == 'POST':
        postdata = request.POST
        email = postdata.get('email')
        name = postdata.get('name')
        message = postdata.get('message')
        savedata = Message(email = email,name = name, message = message)
        savedata.save()
       
    data ={
        "courses":courses
    } 
    return render(request,'courses\home.html',data)