from courses.views.homepage import home
from courses.views.courses import coursePage, MyCoursesList
from courses.views.auth import SignupView,LoginView,signout
from courses.views.checkout import checkout,verifypayment
from courses.views.couponcode import couponcode