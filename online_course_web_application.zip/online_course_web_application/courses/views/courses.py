from django.shortcuts import render,redirect
from django.http import HttpResponse
from courses.models.courses import Course
from courses.models.user_course import UserCourse
from courses.models.video import Video
from django.contrib.auth.decorators import login_required
from django.views.generic import ListView
from django.utils.decorators import method_decorator

# new class based view for my course page 
@method_decorator(login_required(login_url='login') , name='dispatch')
class MyCoursesList(ListView):
    template_name = 'courses\mycourse.html'
    context_object_name = 'user_courses'
    def get_queryset(self):
        return UserCourse.objects.filter(user = self.request.user)


# function for my course page
# @login_required(login_url = "login")
# def mycourse(request):
#     user = request.user
    
#     user_course = UserCourse.objects.filter(user = user )
#     data = {
#         "user_course":user_course,
        
#     }
#     return render(request,'courses\mycourse.html', data)

def coursePage(request,slug):
    course = Course.objects.get(slug = slug)
    serial_number = request.GET.get('lecture')
    videos = course.video_set.all().order_by('serial_number')
    if serial_number is None:
        serial_number = 1
    video = Video.objects.get(serial_number = serial_number , course = course)
    # print("priview", video.is_preview)
    # print(request.user.is_authenticated)
    # print(request.user)

    if (video.is_preview is False):

        if (request.user.is_authenticated is False):
            return redirect('login')
        else:
            user = request.user
            try:
                user_course = UserCourse.objects.get(user = user , course = course)
                
            except:
                return redirect('checkout',slug = course.slug)

    data = {
        "course":course,
        "video":video,
        "videos":videos
    }
    return render(request,'courses\courses.html',data)