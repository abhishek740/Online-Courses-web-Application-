from courses.forms.regiestrationForm import RegistrationForm
from courses.forms.login_form import LoginForm